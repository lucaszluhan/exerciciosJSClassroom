//exercicio 1
let exercicio1 = document.getElementById('exercicio1');

function addContent() {
   exercicio1.innerHTML = '<p>lorem</p>';
}
addContent();
